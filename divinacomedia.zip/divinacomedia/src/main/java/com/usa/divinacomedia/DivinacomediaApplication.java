package com.usa.divinacomedia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DivinacomediaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DivinacomediaApplication.class, args);
	}

}
