package com.usa.divinacomedia.app.repositories;

import com.usa.divinacomedia.app.model.User;
import com.usa.divinacomedia.app.repositories.crud.UserCrudRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @author JORGE CORTES
 */
@Repository

public class UserRepository {
    @Autowired
    private UserCrudRepository repository;

    /**
     *
     * @return
     */
    public List<User> getAll(){
        return (List<User>) repository.findAll();
    }

    /**
     *
     * @param name
     * @return
     */
    public Optional<User> getUserByName(String name){
        return repository.findByName(name);
    }

    /**
     *
     * @param email
     * @return
     */
    public Optional<User> getUserByEmail(String email){
        return repository.findByEmail(email);
    }

    /**
     *
     * @param name
     * @param email
     * @return
     */
    public List<User> getUserByNameorEmail(String name, String email){
        return repository.findByNameOrEmail(name, email);
    }

    /**
     *
     * @param email
     * @param Password
     * @return
     */
    public Optional<User> getUserByEmailAndPassword(String email, String Password){
        return repository.findByEmailAndPassword(email, Password);
    }

    /**
     *
     * @param id
     * @return
     */
    public Optional<User> getUserById(Integer id){
        return repository.findById(id);
    }

    /**
     *
     * @param user
     * @return
     */
    public User save(User user){
        return repository.save(user);
    }

}
