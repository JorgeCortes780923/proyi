package com.usa.divinacomedia.app.repositories.crud;

import com.usa.divinacomedia.app.model.User;
import com.usa.divinacomedia.app.repositories.UserRepository;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

/**
 * @author JORGE CORTES
 */
public interface UserCrudRepository extends CrudRepository<User,Integer> {

    /**
     *
     * @param name
     * @return
     */
    public Optional<User> findByName(String name);

    /**
     *
     * @param email
     * @return
     */
    public Optional<User> findByEmail(String email);

    /**
     *
     * @param email
     * @param password
     * @return
     */
    public Optional<User> findByEmailAndPassword(String email, String password);

    /**
     *
     * @param name
     * @param email
     * @return
     */
    // equivalencia en sql "Select * from user where user_name =' ' or user_email =' '"
    public List<User> findByNameOrEmail(String name, String email);




}
